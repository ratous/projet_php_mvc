<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulter fiches de frais</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body>
    <div class="navbar">
        <a href="accueil_visiteur.php">Accueil</a>
        <a href="consulter_fiches_de_frais.php">Consulter</a>
        <a href="renseigner_fiche_de_frais.php">Renseigner</a>
        
    </div>
    <img src="logo.jfif" alt="Logo" style="float: right; height: 90px;">
    <div class="fiches-container">
        <h2>Consulter fiches de frais</h2>
        <form action="consulter_fiches_de_frais.php" method="post">
            <label for="mois">Sélectionner un mois :</label>
            <select id="mois" name="mois" required>
                <!-- Options de sélection des mois -->
                <!-- Vous pouvez générer dynamiquement les options en fonction des mois disponibles pour l'utilisateur -->
                <option value="01" <?php if(isset($_POST["mois"]) && $_POST["mois"] == "01") echo "selected"; ?>>Janvier</option>
                <option value="02" <?php if(isset($_POST["mois"]) && $_POST["mois"] == "02") echo "selected"; ?>>Février</option>
                <option value="03" <?php if(isset($_POST["mois"]) && $_POST["mois"] == "03") echo "selected"; ?>>Mars</option>
                <option value="04" <?php if(isset($_POST["mois"]) && $_POST["mois"] == "04") echo "selected"; ?>>Avril</option>
                <option value="05" <?php if(isset($_POST["mois"]) && $_POST["mois"] == "05") echo "selected"; ?>>Mai</option>
                <option value="06" <?php if(isset($_POST["mois"]) && $_POST["mois"] == "06") echo "selected"; ?>>Juin</option>
                <option value="07" <?php if(isset($_POST["mois"]) && $_POST["mois"] == "07") echo "selected"; ?>>Juillet</option>
                <option value="08" <?php if(isset($_POST["mois"]) && $_POST["mois"] == "08") echo "selected"; ?>>Aout</option>
                <option value="09" <?php if(isset($_POST["mois"]) && $_POST["mois"] == "09") echo "selected"; ?>>Septembre</option>
                <option value="10" <?php if(isset($_POST["mois"]) && $_POST["mois"] == "10") echo "selected"; ?>>Octobre</option>
                <option value="11" <?php if(isset($_POST["mois"]) && $_POST["mois"] == "11") echo "selected"; ?>>Novembre</option>
                <option value="12" <?php if(isset($_POST["mois"]) && $_POST["mois"] == "12") echo "selected"; ?>>Décembre</option>

                <!-- Ajoutez les autres mois jusqu'au mois actuel -->
            </select>
            <input type="submit" value="Valider">
        </form>
    </div>

    <div class="content">
        <!-- Contenu de la page -->
    </div>
</body>
</html>
