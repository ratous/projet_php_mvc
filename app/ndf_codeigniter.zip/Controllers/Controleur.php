<?php
//acces au controller parent pour l heritage
namespace App\Controllers;
use CodeIgniter\Controller;

//=========================================================================================
//définition d'une classe Controleur (meme nom que votre fichier Controleur.php) 
//héritée de Controller et permettant d'utiliser les raccoucis et fonctions de CodeIgniter
//  Attention vos Fichiers et Classes Controleur et Modele doit commencer par une Majuscule 
//  et suivre par des minuscules
//=========================================================================================

class Controleur extends BaseController {

//=====================================================================
//Fonction index correspondant au Controleur frontal (ou index.php) en MVC libre
//=====================================================================

//public function index(){
//				if ($getdata?index) {
//					return view('connexion');  // Affiche la première page
//				} else {
//					return view('accueil');  // Affiche la deuxième page
//				}
			
//}

public function index(){
	if (isset($_POST['login'])) {$this->motdp();}
    else if (isset($_GET['action']) && isset($_GET['action'])=='index') {$this->connex();}
	else $this->connex();
}

public function motdp() {
	$Modele = new \App\Models\Modele();

	$login = $_POST['login'];
	$motdp = $_POST['mdp'];

	$donnees = $Modele->getindex($login, $motdp);

	if (isset($donnees[0]->login)) {
		$data['login']=$donnees[0]->login;
		echo view('accueil', $data);
	}
	else {
		echo view('connexion');
	}
}

public function consulter(){
	if (isset($_POST['login'])) {$this->motdp();}
    else if (isset($_GET['action']) && isset($_GET['action'])=='index') {$this->connex();}
	else $this->connex();
}

public function mois() {
	$Modele = new \App\Models\Modele();

	$mois_selectionne = $_POST['mois_selectionne'];


	$donnees = $Modele->getmois($mois_selectionne);

	if (isset($donnees[0]->mois_selectionne)) {
		$data['mois_selectionne']=$donnees[0]->mois_selectionne;
		echo view('consulter', $data);
	}
	else {
		echo view('erreur');
	}
}




public function connex() {
	echo view('connexion');
}

public function acc() {
	echo view('accueil');
}

// Affiche une erreur
public function erreur($msgErreur) {
  echo view('vueErreur.php', $data);
}

//==========================
//Fin du code du controleur simple
//===========================

//fin de la classe
}



?>